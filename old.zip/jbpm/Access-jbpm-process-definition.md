Refer to 
```java
KModuleDeploymentService.deploy(DeploymentUnit unit);

KModuleDeploymentService.processResources(InternalKieModule module, Collection<String> files,
KieContainer kieContainer, DeploymentUnit unit, DeployedUnitImpl deployedUnit, ReleaseId releaseId, Map<String, ProcessDescriptor> processes)
```

Have to load process definition from kjar before accessing DefinitionService methods, 
such as DefinitionService.getTaskInputMappings(deploymentId, processId, taskName), 
DefinitionService.getProcessVariables(deploymentId, processId), 
DefinitionService.getTaskInputMappings(deploymentId, processId, taskName)

Refer to the below code block to learn how to load process definition. 
Alternatively, the DeploymentService.deploy will load the definition as well.

```java
//key is deployment id, value is boolean indicating if the deployment unit is loaded
private static Map<String, Boolean> definitionLoadedMarker = new HashMap<String, Boolean>();
private DefinitionService bpmn2Service;
private TransactionalCommandService commandService;
/**
	 * Load process definitions of all deployment units
	 */
	private void loadProcessDefinitions() {
		DeploymentStore deploymentStore = new DeploymentStore();
		deploymentStore.setCommandService(commandService);
		Collection<DeploymentUnit> deploymentUnits = deploymentStore.getEnabledDeploymentUnits();
		if (null != deploymentUnits) {
			for (DeploymentUnit unit : deploymentUnits) {
				String deploymentId = unit.getIdentifier();
				if (definitionLoadedMarker.containsKey(deploymentId)) {
					logger.debug("The process definitions in deployment unit {} were loaded.", deploymentId);
					continue;
				} else {
					definitionLoadedMarker.put(deploymentId, true);
					loadProcessDefinitionsFromDeploymentUnit(unit);
				}
			}
		}
	}
	/**
	 * Load process definitions from one given deployment unit
	 */
	private void loadProcessDefinitionsFromDeploymentUnit(DeploymentUnit unit) {
		String deploymentId = unit.getIdentifier();
		logger.debug("The process definitions in deployment unit {} are loading.", deploymentId);
		String[] strs = deploymentId.split(":");
		KieServices ks = KieServices.Factory.get();
		ReleaseId releaseId = ks.newReleaseId(strs[0], strs[1], strs[2]);
		KieContainer kieContainer = ks.newKieContainer(releaseId);
		KModuleDeploymentUnit kmoduleUnit = (KModuleDeploymentUnit)unit;
		String kbaseName = kmoduleUnit.getKbaseName();
		if (StringUtils.isEmpty(kbaseName)) {
			KieBaseModel defaultKBaseModel = ((KieContainerImpl)kieContainer).getKieProject().getDefaultKieBaseModel();
			if (defaultKBaseModel != null) {
				kbaseName = defaultKBaseModel.getName();
			} else {
				kbaseName = "defaultKieBase";
			}
		}
		InternalKieModule module = (InternalKieModule)((KieContainerImpl)kieContainer).getKieModuleForKBase(kbaseName);
		if (module == null) {
			throw new IllegalStateException(
					"Cannot find kbase, either it does not exist or there are multiple default kbases in kmodule.xml");
		}
		Collection<String> files = module.getFileNames();
		for (String fileName : files) {
			logger.debug("The diagram file is {}", fileName);
			if (fileName.matches(".+bpmn[2]?$")) {
				try {
					String processString = new String(module.getBytes(fileName), "UTF-8");
					bpmn2Service.buildProcessDefinition(deploymentId, processString, kieContainer,
						true);
				} catch (UnsupportedEncodingException e) {
					logger.warn("Unexpected error while performing process definition {}", fileName, e);
				}
			}
		}
	}
```
