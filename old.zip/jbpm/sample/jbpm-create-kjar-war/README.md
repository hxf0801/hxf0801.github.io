rewards-basic
=============

This is an example web application for jBPM 6. It was based on https://github.com/jsvitak/jbpm-6-examples/tree/master/rewards-basic.

Also the project has changed for WebSphere Java EE 6.

This simple example aims to provide an example usage of:
- Human tasks
- jBPM EJB services
 - Deployment service
 - Process service
 - Runtime data service
 - User task service
- Persistence configuration 
- JSP frontend
- Maven build
- automatically create a kjar (org.jbpm.examples:rewards:1.0) from bpmn file and deploy it to local maven repository and runtime engine

### Steps to run
- Make sure you have at least JDK 6 and Maven 3 installed
- configuration of WebSphere on JVM parameters:
    org.guvnor.m2repo.dir=$P{env.jvm.bpm.repository.dir}/kie
    kie.maven.settings.custom=$P{env.config.dir}/mavenSettings.xml
-- data source of WebSphere
    make sure data source to conform with persistence.xml

- Build and deploy the example application:
```sh
cd jbpm-6-examples/rewards-basic
mvn clean package
```
- Visit http://localhost:9080/rewards-basic/ with a web browser
 - [Start Reward Process] is to start a new process
 - [Jiri's Task] is to list Jiri's tasks and approve them
 - [Mary's Task] is to list Mary's tasks and approve them


