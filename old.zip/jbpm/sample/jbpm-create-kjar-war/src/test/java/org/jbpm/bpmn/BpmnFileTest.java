package org.jbpm.bpmn;

import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.codec.binary.Base64;
import org.drools.compiler.builder.impl.KnowledgeBuilderConfigurationImpl;
import org.drools.compiler.kie.builder.impl.InternalKieModule;
import org.drools.core.SessionConfiguration;
import org.drools.core.impl.EnvironmentFactory;
import org.jbpm.bpmn2.xml.BPMNDISemanticModule;
import org.jbpm.bpmn2.xml.BPMNExtensionsSemanticModule;
import org.jbpm.bpmn2.xml.BPMNSemanticModule;
import org.jbpm.bpmn2.xml.XmlBPMNProcessDumper;
import org.jbpm.compiler.xml.XmlProcessReader;
import org.jbpm.kie.services.impl.bpmn2.ProcessDescriptor;
import org.jbpm.kie.services.impl.model.ProcessAssetDesc;
import org.jbpm.process.instance.event.DefaultSignalManagerFactory;
import org.jbpm.process.instance.impl.DefaultProcessInstanceManagerFactory;
import org.jbpm.ruleflow.core.RuleFlowProcess;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieModule;
import org.kie.api.builder.KieRepository;
import org.kie.api.builder.Message.Level;
import org.kie.api.builder.ReleaseId;
import org.kie.api.definition.process.Process;
import org.kie.api.io.Resource;
import org.kie.api.runtime.Environment;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.KieSessionConfiguration;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.internal.KnowledgeBaseFactory;
import org.kie.internal.builder.KnowledgeBuilderConfiguration;
import org.kie.internal.builder.KnowledgeBuilderFactory;
import org.kie.internal.io.ResourceFactory;
import org.kie.internal.runtime.StatefulKnowledgeSession;
import org.kie.internal.runtime.conf.ForceEagerActivationOption;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class BpmnFileTest {
	private static final Logger logger = LoggerFactory.getLogger(BpmnFileTest.class.getName());
	private KieBase kbase;

	@Before
	public void setup() {
		try {
			kbase = createKnowledgeBase("process.bpmn", "test.bpmn2");
		} catch (Exception e) {
			logger.error("creating kie base error.", e);
		}
	}
	@Test
	public void testBpmnDiagram() {
		try {
			// check each file
			Map<String, ProcessDescriptor> processDescriptors = new HashMap<String, ProcessDescriptor>();
			for (Process process : kbase.getProcesses()) {
				processDescriptors.put(process.getId(),
					(ProcessDescriptor)process.getMetaData().get("ProcessDescriptor"));
			}
			logger.debug("process diagram collection is {}", processDescriptors);
			String processId = "fsc.cda.test";
			ProcessDescriptor processDesriptor = processDescriptors.get(processId);
			if (processDesriptor != null) {
				ProcessAssetDesc process = processDesriptor.getProcess();
				if (process == null) {
					throw new IllegalArgumentException("Unable to read process " + processId);
				}
				logger.debug("logging process id {}, process {}", process.getId(), process);
			}

			KieRepository kieRepository = KieServices.Factory.get().getRepository();
			logger.debug("kie repository is {}", kieRepository);
			ReleaseId releaseId = kieRepository.getDefaultReleaseId();
			logger.debug("default deployment id is {}", releaseId);

			String containerId = ((org.drools.core.impl.InternalKnowledgeBase)kbase).getContainerId();
			logger.debug("default kie container id is {}", containerId);

			KieModule kieModule = kieRepository.getKieModule(releaseId);
			logger.debug("default kie module is {}", kieModule);

			InternalKieModule kmodule = (InternalKieModule)kieModule;
			Collection<String> files = kmodule.getFileNames();

			processResources(releaseId, kmodule, files, processDescriptors);
		} catch (Exception e) {
			logger.error("testBpmnDiagram", e);
		}
	}

	//second test
	//@Test
	public void testBpmn() {
		try {
			KieSession ksession = createKnowledgeSession(kbase);
			ProcessInstance processInstance = ksession.startProcess("fsc.cda.adminProcess");
			Assert.assertTrue(processInstance.getProcessId().equals("fsc.cda.adminProcess"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected KieBase createKnowledgeBase(String... process)
		throws Exception {
		List<Resource> resources = new ArrayList<Resource>();
		for (int i = 0; i < process.length; ++i) {
			resources.addAll(buildAndDumpBPMN2Process(process[i]));
		}
		return createKnowledgeBaseFromResources(resources.toArray(new Resource[resources.size()]));
	}

	// Important to test this since persistence relies on this
	protected List<Resource> buildAndDumpBPMN2Process(String process)
		throws SAXException, IOException {
		KnowledgeBuilderConfiguration conf = KnowledgeBuilderFactory.newKnowledgeBuilderConfiguration();
		((KnowledgeBuilderConfigurationImpl)conf).initSemanticModules();
		((KnowledgeBuilderConfigurationImpl)conf).addSemanticModule(new BPMNSemanticModule());
		((KnowledgeBuilderConfigurationImpl)conf).addSemanticModule(new BPMNDISemanticModule());
		((KnowledgeBuilderConfigurationImpl)conf).addSemanticModule(new BPMNExtensionsSemanticModule());
		Resource classpathResource = ResourceFactory.newClassPathResource(process);
		// Dump and reread
		XmlProcessReader processReader =
			new XmlProcessReader(((KnowledgeBuilderConfigurationImpl)conf).getSemanticModules(), getClass()
					.getClassLoader());
		List<Process> processes = processReader.read(this.getClass().getResourceAsStream("/" + process));
		List<Resource> resources = new ArrayList<Resource>();
		for (Process p : processes) {
			RuleFlowProcess ruleFlowProcess = (RuleFlowProcess)p;
			String dumpedString = XmlBPMNProcessDumper.INSTANCE.dump(ruleFlowProcess);
			Resource resource = ResourceFactory.newReaderResource(new StringReader(dumpedString));
			resource.setSourcePath(classpathResource.getSourcePath());
			resource.setTargetPath(classpathResource.getTargetPath());
			resources.add(resource);
		}
		return resources;
	}

	protected KieBase createKnowledgeBaseFromResources(Resource... process)
		throws Exception {
		KieServices ks = KieServices.Factory.get();
		KieRepository kr = ks.getRepository();
		if (process.length > 0) {
			KieFileSystem kfs = ks.newKieFileSystem();
			for (Resource p : process) {
				kfs.write(p);
			}
			KieBuilder kb = ks.newKieBuilder(kfs);
			kb.buildAll(); // kieModule is automatically deployed to KieRepository
							// if successfully built.
			if (kb.getResults().hasMessages(Level.ERROR)) {
				throw new RuntimeException("Build Errors:\n" + kb.getResults().toString());
			}
		}
		KieContainer kContainer = ks.newKieContainer(kr.getDefaultReleaseId());
		return kContainer.getKieBase();
	}

	protected StatefulKnowledgeSession createKnowledgeSession(KieBase kbase)
		throws Exception {
		return createKnowledgeSession(kbase, null, null);
	}

	protected StatefulKnowledgeSession createKnowledgeSession(KieBase kbase, KieSessionConfiguration conf,
			Environment env)
		throws Exception {
		StatefulKnowledgeSession result;
		if (conf == null) {
			conf = KnowledgeBaseFactory.newKnowledgeSessionConfiguration();
		}
		if (env == null) {
			env = EnvironmentFactory.newEnvironment();
		}
		Properties defaultProps = new Properties();
		defaultProps.setProperty("drools.processSignalManagerFactory", DefaultSignalManagerFactory.class.getName());
		defaultProps.setProperty("drools.processInstanceManagerFactory",
			DefaultProcessInstanceManagerFactory.class.getName());
		conf = SessionConfiguration.newInstance(defaultProps);
		conf.setOption(ForceEagerActivationOption.YES);
		result = (StatefulKnowledgeSession)kbase.newKieSession(conf, env);
		return result;
	}

	protected void processResources(ReleaseId releaseId, InternalKieModule module, Collection<String> files,
			Map<String, ProcessDescriptor> processes) {
		String deploymentId = releaseId.toExternalForm();
		for (String fileName : files) {
			logger.debug("file name is {}", fileName);
			if (fileName.matches(".+bpmn[2]?$")) {
				ProcessAssetDesc process;
				try {
					String processString = new String(module.getBytes(fileName), "UTF-8");
					String processId = getProcessId(processString);
					ProcessDescriptor processDesriptor = processes.get(processId);
					if (processDesriptor != null) {
						process = processDesriptor.getProcess();
						if (process == null) {
							throw new IllegalArgumentException("Unable to read process " + fileName);
						}
						process.setEncodedProcessSource(Base64.encodeBase64String(processString.getBytes()));
						process.setDeploymentId(deploymentId);
						logger.debug("addAssetLocation process id{}, process {}", process.getId(), process);
					}
				} catch (UnsupportedEncodingException e) {
					throw new IllegalArgumentException("Unsupported encoding while processing process " + fileName);
				}
			} else if (fileName.matches(".+ftl$") || fileName.matches(".+form$")) {
				try {
					String formContent = new String(module.getBytes(fileName), "UTF-8");
					if (fileName.indexOf("/") != -1)
						fileName = fileName.substring(fileName.lastIndexOf("/") + 1);
					logger.debug("registerForm id {}, fileName {}, formContent {}.", deploymentId, fileName,
						formContent);
				} catch (UnsupportedEncodingException e) {
					throw new IllegalArgumentException("Unsupported encoding while processing form " + fileName);
				}
			}
		}
	}

	protected String getProcessId(String processSource) {
		try {
			String PROCESS_ID_XPATH = "/*[local-name() = 'definitions']/*[local-name() = 'process']/@id";
			XPathExpression processIdXPathExpression = XPathFactory.newInstance().newXPath().compile(PROCESS_ID_XPATH);
			InputSource inputSource = new InputSource(new StringReader(processSource));
			String processId = (String)processIdXPathExpression.evaluate(inputSource, XPathConstants.STRING);
			return processId;
		} catch (XPathExpressionException e) {
			logger.error("Unable to find process id from process source due to {}", e.getMessage());
			return null;
		}
	}
}
