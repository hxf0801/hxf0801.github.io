package org.jbpm.examples.runtime;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.io.IOUtils;
import org.apache.maven.model.Model;
import org.apache.maven.model.io.xpp3.MavenXpp3Writer;
import org.eclipse.aether.artifact.Artifact;
import org.eclipse.aether.artifact.DefaultArtifact;
import org.eclipse.aether.deployment.DeployRequest;
import org.eclipse.aether.deployment.DeploymentException;
import org.eclipse.aether.installation.InstallRequest;
import org.eclipse.aether.installation.InstallationException;
import org.eclipse.aether.repository.RemoteRepository;
import org.eclipse.aether.repository.RepositoryPolicy;
import org.eclipse.aether.util.artifact.SubArtifact;
import org.kie.api.builder.ReleaseId;
import org.kie.scanner.Aether;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KjarM2Repository {
	private static final Logger logger = LoggerFactory.getLogger(KjarM2Repository.class);
	private static final String DEFAULT_M2_REPO_ROOT = "repositories" + File.separatorChar + "kie";
	private static String M2_REPO_DIR;
	private static final int BUFFER_SIZE = 1024;

	public KjarM2Repository() {
		final String meReposDir = System.getProperty("org.guvnor.m2repo.dir", DEFAULT_M2_REPO_ROOT);
		if (meReposDir == null || meReposDir.trim().isEmpty()) {
			M2_REPO_DIR = DEFAULT_M2_REPO_ROOT;
		} else {
			M2_REPO_DIR = meReposDir.trim();
		}
		logger.debug("Maven Repository root set to:[{}]", M2_REPO_DIR);
		//Ensure repository root has been created
		final File root = new File(getM2RepositoryRootDir());
		if (!root.exists()) {
			logger.debug("Creating Maven Repository root:[{}]", M2_REPO_DIR);
			root.mkdirs();
		}
		Aether.getAether().getRepositories().add(getGuvnorM2Repository());
	}

	public String getM2RepositoryRootDir() {
		if (!M2_REPO_DIR.endsWith(File.separator)) {
			return M2_REPO_DIR + File.separator;
		} else {
			return M2_REPO_DIR;
		}
	}

	public void deployArtifact(final InputStream inputStream, final ReleaseId releaseId,
			final boolean includeAdditionalRepositories) {
		//Write JAR to temporary file for deployment
		File jarFile = new File(System.getProperty("java.io.tmpdir"), toFileName(releaseId, "jar"));
		try {
			try {
				if (!jarFile.exists()) {
					jarFile.getParentFile().mkdirs();
					jarFile.createNewFile();
				}
				FileOutputStream fos = new FileOutputStream(jarFile);
				final byte[] buf = new byte[BUFFER_SIZE];
				int byteRead = 0;
				while ((byteRead = inputStream.read(buf)) != -1) {
					fos.write(buf, 0, byteRead);
				}
				fos.flush();
				fos.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
			//Write pom.xml to JAR if it doesn't already exist
			String pomXML = loadPOMFromJarInternal(new File(jarFile.getPath()));
			deployArtifact(releaseId, pomXML, jarFile, includeAdditionalRepositories);
		} finally {
			try {
				jarFile.delete();
			} catch (Exception e) {
				logger.warn("Unable to remove temporary file '" + jarFile.getAbsolutePath() + "'");
			}
		}
	}

	public void deployArtifact(final ReleaseId releaseId, final String pomXML, final File jarFile,
			final boolean includeAdditionalRepositories) {
		//Write pom.xml to temporary file for deployment
		final File pomXMLFile = new File(System.getProperty("java.io.tmpdir"), toFileName(releaseId, "pom.xml"));
		try {
			try {
				if (!pomXMLFile.exists()) {
					pomXMLFile.getParentFile().mkdirs();
					pomXMLFile.createNewFile();
				}
				FileOutputStream fos = new FileOutputStream(pomXMLFile);
				IOUtils.write(pomXML, fos);
				fos.flush();
				fos.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
			//JAR Artifact
			Artifact jarArtifact =
				new DefaultArtifact(releaseId.getGroupId(), releaseId.getArtifactId(), "jar", releaseId.getVersion());
			jarArtifact = jarArtifact.setFile(jarFile);
			//pom.xml Artifact
			Artifact pomXMLArtifact = new SubArtifact(jarArtifact, "", "pom");
			pomXMLArtifact = pomXMLArtifact.setFile(pomXMLFile);
			try {
				//Install into local repository
				final InstallRequest installRequest = new InstallRequest();
				installRequest.addArtifact(jarArtifact).addArtifact(pomXMLArtifact);
				Aether.getAether().getSystem().install(Aether.getAether().getSession(), installRequest);
			} catch (InstallationException e) {
				throw new RuntimeException(e);
			}
			//Deploy into Workbench's default remote repository
			try {
				final DeployRequest deployRequest = new DeployRequest();
				deployRequest.addArtifact(jarArtifact).addArtifact(pomXMLArtifact)
				.setRepository(getGuvnorM2Repository());
				Aether.getAether().getSystem().deploy(Aether.getAether().getSession(), deployRequest);
			} catch (DeploymentException e) {
				throw new RuntimeException(e);
			}
			//Only deploy to additional repositories if required. This flag is principally for Unit Tests
			if (!includeAdditionalRepositories) {
				return;
			}
		} finally {
			try {
				pomXMLFile.delete();
			} catch (Exception e) {
				logger.warn("Unable to remove temporary file '" + pomXMLFile.getAbsolutePath() + "'");
			}
		}
	}

	private RemoteRepository getGuvnorM2Repository() {
		File m2RepoDir = new File(M2_REPO_DIR);
		if (!m2RepoDir.exists()) {
			logger.error("Repository root does not exist: " + M2_REPO_DIR);
			throw new IllegalArgumentException("Repository root does not exist: " + M2_REPO_DIR);
		}
		try {
			String localRepositoryUrl = m2RepoDir.toURI().toURL().toExternalForm();
			return new RemoteRepository.Builder("guvnor-m2-repo", "default", localRepositoryUrl)
			.setSnapshotPolicy(
				new RepositoryPolicy(
					true, RepositoryPolicy.UPDATE_POLICY_DAILY, RepositoryPolicy.CHECKSUM_POLICY_WARN))
					.setReleasePolicy(
						new RepositoryPolicy(
							true, RepositoryPolicy.UPDATE_POLICY_ALWAYS, RepositoryPolicy.CHECKSUM_POLICY_WARN))
							.build();
		} catch (MalformedURLException e) {
			logger.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	private String loadPOMFromJarInternal(final File file) {
		try (ZipFile zip = new ZipFile(file)) {
			for (Enumeration<? extends ZipEntry> e = zip.entries(); e.hasMoreElements();) {
				ZipEntry entry = e.nextElement();
				if (entry.getName().startsWith("META-INF/maven") && entry.getName().endsWith("pom.xml")) {
					try (InputStream is = zip.getInputStream(entry);
							InputStreamReader isr = new InputStreamReader(is, "UTF-8")) {
						StringBuilder sb = new StringBuilder();
						for (int c = isr.read(); c != -1; c = isr.read()) {
							sb.append((char)c);
						}
						return sb.toString();
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	public String toFileName(final ReleaseId releaseId, final String fileName) {
		return releaseId.getGroupId()
				+ "-"
			+ releaseId.getArtifactId()
				+ "-"
			+ releaseId.getVersion()
				+ "-"
				+ Math.random()
				+ "."
				+ fileName;
	}

	public String generatePOM(final ReleaseId releaseId) {
		Model model = new Model();
		model.setGroupId(releaseId.getGroupId());
		model.setArtifactId(releaseId.getArtifactId());
		model.setVersion(releaseId.getVersion());
		model.setModelVersion("4.0.0");
		StringWriter stringWriter = new StringWriter();
		try {
			new MavenXpp3Writer().write(stringWriter, model);
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		return stringWriter.toString();
	}
}