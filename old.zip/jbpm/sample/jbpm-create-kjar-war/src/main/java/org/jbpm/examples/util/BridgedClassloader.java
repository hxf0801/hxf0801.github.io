package org.jbpm.examples.util;

import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;


public class BridgedClassloader extends ClassLoader {
	private static final Logger LOG = org.slf4j.LoggerFactory.getLogger(BridgedClassloader.class);

	private final ClassLoader secondary;
	private List<ClassLoader> classLoaders = new LinkedList<ClassLoader>();

	public BridgedClassloader(ClassLoader primary, ClassLoader secondary) {
		super(primary);
		this.secondary = secondary;
		put(primary);
		put(secondary);
	}

	@Override
	protected Class<?> findClass(String name) throws ClassNotFoundException {
		try {
			return this.getParent().loadClass(name);
		}
		catch(ClassNotFoundException e) {
			LOG.trace("Looking up class["+name+"] in secondary classloader.");
			return secondary.loadClass(name);
		}
	}

	@Override
	public Class<?> loadClass(String name) throws ClassNotFoundException {
		LOG.trace("Trying to load class: "+name);
		try {
			return this.getParent().loadClass(name);
		}
		catch(ClassNotFoundException e) {
			LOG.trace("Looking up class["+name+"] in secondary classloader.");
			return secondary.loadClass(name);
		}
	}

	@Override
	public String toString() {
		return "BridgedClassloader [parent="+getParent()+"], secondary=" + secondary + "]";
	}

	/**
	 * Specify a new class loader to be used in searching. The order of loaders
	 * determines the order of the result. It is recommended to add the most
	 * specific loaders first; {@code null} class loaders are discarded.
	 * @param classLoader
	 *        The class loader has to added in the set
	 */
	private void put(ClassLoader classLoader) {
		if (classLoader != null) {
			classLoaders.add(classLoader);
		}
	}
}
