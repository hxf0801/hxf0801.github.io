package org.jbpm.examples.util;

public interface WfeWebConstants {
	String DEPLOYMENT_ID = "org.jbpm.examples:rewards:1.0";
	String GROUP_ID = "org.jbpm.examples";
	String ARTIFACT_ID = "rewards";
	String VERSION = "1.0";
}
