package org.jbpm.examples.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.io.IOUtils;
import org.eclipse.aether.artifact.Artifact;
import org.kie.api.builder.ReleaseId;
import org.kie.scanner.MavenRepository;
import org.mvel2.MVEL;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WorkItemDefinitionUtil {

	private static final Logger LOG = LoggerFactory.getLogger(WorkItemDefinitionUtil.class);

	public static List<Map<String, Object>> loadWorkItemDefinitions(ReleaseId releaseId, String pattern) {
		Artifact artifact = MavenRepository.getMavenRepository().resolveArtifact(releaseId.toString());

		LOG.debug("Artifact found: "+artifact);

		File jar = artifact.getFile();
		LOG.debug("File reference: "+jar.getAbsolutePath());
		LOG.debug("Loading entry: "+pattern);
		try (ZipFile zip = new ZipFile(jar)) {
			ZipEntry entry = zip.getEntry(pattern);
			if (entry == null) {
				LOG.warn("Did not find " + pattern);
				return new LinkedList<Map<String, Object>>();
			}

			LOG.debug("Found entry: " + entry);
			try (InputStream is = zip.getInputStream(entry)) {
				String content = IOUtils.toString(is);
				List<Map<String, Object>> vals =
						(List<Map<String, Object>>)MVEL.eval(content, new HashMap<String, Object>());

				LOG.debug("Read: " + vals.toString());

				return vals;
			} catch (IOException e) {
				LOG.error("Exception reading zip entry " + pattern, e);
			}
		} catch (Exception e) {
			LOG.error("Exception reading zip to find entry " + pattern, e);
		}

		return null;
	}

}
