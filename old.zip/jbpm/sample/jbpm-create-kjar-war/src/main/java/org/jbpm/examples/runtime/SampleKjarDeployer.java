package org.jbpm.examples.runtime;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.DependsOn;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import org.drools.compiler.kie.builder.impl.InternalKieModule;
import org.jbpm.examples.util.WfeWebConstants;
import org.jbpm.kie.services.impl.KModuleDeploymentUnit;
import org.jbpm.services.ejb.api.DeploymentServiceEJBLocal;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Message;
import org.kie.api.builder.ReleaseId;
import org.kie.api.builder.model.KieBaseModel;
import org.kie.api.builder.model.KieModuleModel;
import org.kie.api.builder.model.KieSessionModel;
import org.kie.api.conf.EqualityBehaviorOption;
import org.kie.api.conf.EventProcessingOption;
import org.kie.api.runtime.conf.ClockTypeOption;
import org.kie.internal.io.ResourceFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Programmatically creating and deploying some BPMN diagrams. It the
 * <code>DeploymentSynchronizerEJBImpl</code> should start up before it to make
 * sure the deploying event is listened and can be persisted into db.
 * @author shu
 */
@Singleton
@Startup
@DependsOn("DeploymentSynchronizerEJBImpl")
public class SampleKjarDeployer {
	private static final Logger logger = LoggerFactory.getLogger(SampleKjarDeployer.class.getName());

	@EJB
	private DeploymentServiceEJBLocal deploymentService;

	private KjarM2Repository repository;

	@PostConstruct
	public void installAndDeploy() {
		System.setProperty("org.jbpm.ht.callback", "custom");
		System.setProperty("org.jbpm.ht.custom.callback", RewardsUserGroupCallback.class.getName());

		repository = new KjarM2Repository();
		installToLocalMavenRepository();
		deploymentService.deploy(new KModuleDeploymentUnit(
			WfeWebConstants.GROUP_ID, WfeWebConstants.ARTIFACT_ID, WfeWebConstants.VERSION));
	}

	private void installToLocalMavenRepository() {
		KieServices ks = KieServices.Factory.get();
		ReleaseId releaseId = ks.newReleaseId(WfeWebConstants.GROUP_ID, WfeWebConstants.ARTIFACT_ID, WfeWebConstants.VERSION);
		List<String> processes = new ArrayList<String>();
		processes.add("rewards.bpmn2");
		InternalKieModule kieModule = createKieJar(ks, releaseId, processes);
		File jarFile = bytesToFile(releaseId, kieModule.getBytes(), ".jar");
		repository.deployArtifact(releaseId, getPom(releaseId), jarFile, true);
	}

	private InternalKieModule createKieJar(KieServices ks, ReleaseId releaseId, List<String> resources) {
		KieFileSystem kfs = createKieFileSystemWithKProject(ks);
		kfs.writePomXML(getPom(releaseId));
		for (String resource : resources) {
			kfs.write("src/main/resources/" + resource, ResourceFactory.newClassPathResource(resource));
		}
		KieBuilder kieBuilder = ks.newKieBuilder(kfs);
		if (!kieBuilder.buildAll().getResults().getMessages().isEmpty()) {
			for (Message message : kieBuilder.buildAll().getResults().getMessages()) {
				logger.error("Error Message: ({}) {}", message.getPath(), message.getText());
			}
			throw new RuntimeException("There are errors builing the package, please check your knowledge assets!");
		}
		return (InternalKieModule)kieBuilder.getKieModule();
	}

	private String getPom(ReleaseId releaseId) {
		return repository.generatePOM(releaseId);
	}

	private KieFileSystem createKieFileSystemWithKProject(KieServices ks) {
		KieModuleModel kproj = ks.newKieModuleModel();
		KieBaseModel kieBaseModel1 =
				kproj.newKieBaseModel("defaultKieBase").setDefault(true).addPackage("*")
				.setEqualsBehavior(EqualityBehaviorOption.EQUALITY)
				.setEventProcessingMode(EventProcessingOption.STREAM);
		kieBaseModel1.newKieSessionModel("defaultKieSession").setDefault(true)
		.setType(KieSessionModel.KieSessionType.STATEFUL).setClockType(ClockTypeOption.get("realtime"));
		KieFileSystem kfs = ks.newKieFileSystem();
		kfs.writeKModuleXML(kproj.toXML());
		return kfs;
	}

	private File bytesToFile(ReleaseId releaseId, byte[] bytes, String extension) {
		File file = new File(System.getProperty("java.io.tmpdir"), repository.toFileName(releaseId, null) + extension);
		try {
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(bytes);
			fos.flush();
			fos.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return file;
	}
}
