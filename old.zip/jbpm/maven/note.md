* delete some unused jars and reduce the size of jbpm kie-wb distribution war.
* using Logback as the logging framework
* SLF4J update to 1.7.22

##############################
为了获得相同的结果，这里提供2种方式来达到目的：一种是用maven+ant；另一种是只使用maven，但是利用overlay特性来去除原始war中不要的文件