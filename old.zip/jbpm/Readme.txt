1. reduce the size of the official release
Step1: rename the official release from <<kie-wb-distribution-wars-6.2.0.Final-was8.war>> to <<kie-wb-distribution-wars-was8.war>>
Step2: remove unused file/folder from the release <<kie-wb-distribution-wars-was8.war>> as listed bullets:
	1) delete folder <banner>
	2) delete folder <formModeler>
	3) delete folder <images>
	4) delete folder <js>
	5) delete folder <org.kie.workbench.KIEWebapp>
	6) delete folder <plugins>
    7) delete files: favicon.ico, index.jsp, kie-wb.html, login.jsp, logout.jsp, not_authorized.jsp, README.md, rest-api.jsp
Step3: further remove unused jars from the release <<kie-wb-distribution-wars-was8.war>>
	Refer to the file WFE\build\build.xml target "official-war.lib.delete" to get detailed file names
Step4. delete folder kie-wb-distribution-wars-was8.war\WEB-INF\tlds        
Step5: delete the following files from the release kie-wb-distribution-wars-was8.war\WEB-INF\classes
	a. author_mappings.properties
	b. classlist.mf
	c. designer.configuration
	d. ErraiApp.properties
	e. jbpm.audit.jms.properties
	f. realm.properties
	g. restricted-groups.properties
	h. userinfo.properties
	i. workbench-policy.properties
Step6. delete folder kie-wb-distribution-wars-was8.war\WEB-INF\classes\org
Step7: clean kie-wb-distribution-wars-was8.war\WEB-INF\classes\META-INF
	a. delete folder kie-wb-distribution-wars-was8.war\WEB-INF\classes\META-INF\sisu
	b. delete file org.uberfire.java.nio.file.spi.FileSystemProvider under META-INF\services
	c. modify file javax.enterprise.inject.spi.Extension under META-INF\services
		delete line: org.jbpm.console.ng.bd.backend.server.profile.ProfileManagerExtension


2. PTI related changes to get wfe.ear based on reduced jbpm official release <<kie-wb-distribution-wars-was8.war>>
step1: add new projects: WFE, WFE-Common and WFE-Web.
	a. WFE-Common has the common classes for all other projects. Depends on only ptutils other than jbpm.
	b. WFE-Server: It only depends on jbpm and makes changes to official jbpm classes. So it is a patch to jbpm.
		note to delete all files under WFE-Server\src\kie-wb-webapp
	c. WFE-Svc: PTI's extension to jbpm. It depends on jbpm, WFE-Common and WFE-Server. So it is an extension to jbpm.
	d. WFE-Config: PTI specific configuration for logging. It integrates PTI's logging into jbpm based on log4j.
	e. WFE-Web: web project. wfe.ear has only WFE-Web.war which contains other jars from project a) to d).
	f. WFE: ear project only has one module: WFE-Web.
Step2: changes to release_WFE
    delete folder release_WFE/lib/guvnor;
    move folder release_WFE/resources/ear/META-INF to WFE. See step6;
    move file release_WFE/resources/ear/war/index.jsp to WFE-Web. See step5-5.3-e;
    move folder release_WFE/resources/ear/war/WEB-INF/classes to WFE-Web. see step5-5.3-a,b,c,d;
    move all files exactly under folder release_WFE/resources/ear/war/WEB-INF to WFE-Web. see step5-5.3-f,g;
    move release_WFE/resources/ear/war/WEB-INF/lib/jbpmmigration-0.13.jar to release_WFE/lib/other-changed;
    move other jars under release_WFE/resources/ear/war/WEB-INF/lib to release_WFE/lib/supplement;
    delete folder release_WFE/resources;
    delete folder release_WFE/lib/jbpm-runtime;
Step3: changes to WFE-Common and WFE-Svc
	a. move classes from WFE-Svc to WFE-Common but keep their full qualified class name
		JbpmServiceAccessor.java,
		JbpmService.java,
		JbpmServiceException.java,
		JbpmServiceLocal.java,
		JbpmServiceRemote.java,
		WfCommandInfo.java,
		WfCommandService.java,
		WfCommandServiceRemote.java,
		WfCommonInfo.java,
		WfProcessInstance.java,
		WfTask.java,
		WfTaskSummary.java
	b. add two new classes to WFE-Common
		com.pti.fsc.common.wf.SearchCriteria as same content as org.kie.api.search.SearchCriteria.
		com.pti.fsc.common.wf.WhereParameter as same content as org.kie.api.search.WhereParameter.
	c. so in wfe client, we don't need the dependency on jbpm. we only use our own classes.
Step4: changes to WFE-Server
	a. add one new class to WFE-Server/src/kie-api
		org.kie.api.search.WfTaskSummary as same content as com.pti.fsc.common.wf.WfTaskSummary.
		
		so in workflow engine (jbpm), it only use jbpm's classes, and don't use our own client classes.
	b. *** potential consideration: 
		decouple jbpm and com.pti.fsc.wfe.util.WfeUserBuCallback.java (WFE-Server/src/jbpm-human-task-core)
		don't directly use new
Step5: changes to WFE-Web
	5.1) PTI own assembled classes under WFE-Web\src\com\pti\fsc\wfe. 
		Finally these classes should go to wfe.ear\WFE-Web.war\WEB-INF\classes.
	5.2) jars in WFE-Web/WebContent/WEB-INF/lib
		a. copy jars from shrinked kie-wb-distribution-wars-was8.war\WEB-INF\lib to here;
		b. copy specific jars under release_WFE/lib/supplement to here:
			javassist-3.18.1-GA.jar; (only for liberty profile)
			org.osgi.core-4.3.1.jar; (only for liberty profile)
            jackson-core-asl-1.9.9.jar; (only for liberty profile)
			slf4j-log4j12-1.7.2.jar;
			log4j-1.2.17.jar;
			ptiutils.jar;
			xalan.jar. (only for liberty profile???)
		c. copy jars from release_WFE/lib/jbpm-changed to here:
			jbpm-audit.jar
			jbpm-executor.jar
			jbpm-flow.jar
			jbpm-human-task-core.jar
			jbpm-human-task-jpa.jar
			jbpm-human-task-workitems.jar
			jbpm-persistence-jpa.jar
			jbpm-runtime-manager.jar
			jbpm-services-cdi.jar
			kie-api.jar
			kie-internal.jar
			kie-remote-jaxb.jar
			kie-remote-services.jar
		d. copy release_WFE/lib/other-changed/jbpmmigration-0.13.jar to here;
	5.3) Application related configuration (need to modify according to the real runtime environment)
		a. JPA persistence unit configuration: WFE-Web/src/META-INF/persistence.xml.
		b. kjar deployment descriptor: WFE-Web/src/META-INF/kie-wb-deployment-descriptor.xml.
		c. user property file: WFE-Web/src/jbpm.user.info.properties.
		d. user group property file: WFE-Web/src/jbpm.usergroup.callback.properties.
		e. welcome index file: WFE-Web/WebContent/index.jsp.
		f. web project related configuration under WFE-Web/WebContent/WEB-INF: 
			beans.xml, 
			ejb-jar.xml, 
			web.xml.
		g. WebSphere specific web project configuration under WFE-Web/WebContent/WEB-INF: 
			ibm-ejb-jar-bnd.xml,
			ibm-ejb-jar-ext.xml,
			ibm-web-bnd.xml,
			ibm-web-ext.xml.
Step6: changes to WFE
	6.1) application deployment descriptor under WFE/META-INF: application.xml.
	6.2) WebSphere specific ear project configuration under WFE/META-INF:
		a. folder <ibmconfig> to define class loader policy,
		b. ibm-application-bnd.xml.

	
3. Workflow engine(wfe) API for its client
	WFE-Client to provide all programming interface to wfe's client to communicate with the engine. 
	The jar is wfe-client.jar which contains the classes in both WFE-Client and WFE-Common.
	So client only depends on wfe-client.jar, and should not touch any jbpm related jars.

4. JVM configuration in runtime
	a. some jvm parameters should can be deleted:
	    org.uberfire.cluster.autostart
	    org.uberfire.metadata.index.dir
	    org.uberfire.nio.git.daemon.enabled
	    org.uberfire.nio.git.dir
	    org.uberfire.nio.git.ssh.cert.dir
	    org.uberfire.nio.git.ssh.enabled
	    org.uberfire.nio.git.ssh.host
	    org.uberfire.nio.git.ssh.port
	    org.uberfire.secure.alg
	    org.uberfire.secure.key
	    org.uberfire.start.method
	    org.uberfire.sys.repo.monitor.disabled
	b. we only needs jvm parameters:
		jbpm.ut.jndi.lookup=jta/usertransaction
		kie.services.jms.queues.response=jms/KIE.RESPONSE.ALL
		kie.services.rest.deploy.async=false
		org.guvnor.m2repo.dir=$P{env.jvm.bpm.repository.dir}/kie
		kie.maven.settings.custom=$P{env.configFileDir}/mavenSettings.xml
		org.kie.demo=false
	c. we only need the runtime folder <kie>. For example, D:/tmp/AppSrv02-OCBCDEV/repository/kie.
	d. we can delete these runtime folders: <cert>, <git>, <index>. For example:
		D:/tmp/AppSrv02-OCBCDEV/repository/cert, 
		D:/tmp/AppSrv02-OCBCDEV/repository/git,
		D:/tmp/AppSrv02-OCBCDEV/repository/index
