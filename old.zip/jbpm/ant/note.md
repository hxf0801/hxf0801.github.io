* delete some unused jars and reduce the size of jbpm kie-wb distribution war.
* using Log4j as the logging framework