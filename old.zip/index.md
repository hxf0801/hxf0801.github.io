# some private notes

* [Use maven to contain another project, finally get one jar](\mvn-two-in-one\pom.xml)

## Section Title

> This block quote is here for your information.
